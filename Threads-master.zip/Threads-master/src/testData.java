
public class testData {

    private int i;

    //increase i method
    public void increaseI(){
        i++;
    }
    //getters and setters
    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }



}
