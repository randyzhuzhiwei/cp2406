
import java.net.*;

public class UDPServer {

    public static void main(String Args[]){
         DatagramSocket socket = null;

        try {
            socket = new DatagramSocket(4445);

                //Listening
                byte[] buf = new byte[256];

                // receive request
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);

                String received = new String(packet.getData(), 0, packet.getLength());
                InetAddress address = packet.getAddress();
                int port = packet.getPort();
                System.out.println("Hey I got this msg! " + received + " from IP:" +address+" port:" +port);


        }
        catch(Exception e)
        {
            System.out.println(e);

        }
    }


}
