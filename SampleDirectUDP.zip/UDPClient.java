import java.net.*;
import java.util.*;

public class UDPClient {

    public static void main(String Args[]) {

        DatagramSocket socket = null;
        String textIn;

        Scanner in= new Scanner(System.in);
        System.out.println("Enter server IP:");
        textIn=in.nextLine().trim();
        int DatagramPort=4446;
        int ServerPort=4445;

        try {
            socket = new DatagramSocket(DatagramPort);
            InetAddress address = InetAddress.getByName(textIn);

            //Sending
            byte[] buf = new byte[256];
            buf="Test msg".getBytes();

            // receive request

            DatagramPacket packet = new DatagramPacket(buf, buf.length, address, ServerPort);
            socket.send(packet);

            System.out.println("Msg sent to "+address);


        }
        catch(Exception e)
        {
            System.out.println(e);

        }
    }


}
